# MailSender
This app allows to send mails from a configurable source to a configurable groups of people with a configurable message.
